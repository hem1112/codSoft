package codSoft.taskThree;

public class ATM {
    private double viewBalance;
    private double depositAmount;
    private double withdrawAmount;


    public ATM(){

    }


    public double getViewBalance() {
        return viewBalance;
    }


    public void setViewBalance(double viewBalance) {
        this.viewBalance = viewBalance;
    }


    public double getDepositAmount() {
        return depositAmount;
    }


    public void setDepositAmount(double depositAmount) {
        this.depositAmount = depositAmount;
    }


    public double getWithdrawAmount() {
        return withdrawAmount;
    }


    public void setWithdrawAmount(double withdrawAmount) {
        this.withdrawAmount = withdrawAmount;
    }
    
    
}
