package codSoft.taskThree;

public interface atmOperationInter {
    public void viewBalance();
    public void depositAmount(double depositAmount);
    public void withdrawAmount(double withdrawAmount );
    public void miniStatement();
    
}
